/* window.onload = function(){
    var container = document.getElementById('container_loader');
    container.style.visibility = 'hidden';
    container.style.opacity = '0';   
} */

// const containerLoader = document.getElementById('container_loader');

// console.log(containerLoader);